// Экспорт компонентов управления контрактами для code-splitting
export { DocumentApproval } from '../contract/DocumentApproval';
export { DocumentApprovalActions } from '../contract/DocumentApprovalActions';
export { DocumentComments } from '../contract/DocumentComments';
export { DocumentUpload } from '../contract/DocumentUpload';
export { QualificationObjectsCRUD } from '../contract/QualificationObjectsCRUD';
