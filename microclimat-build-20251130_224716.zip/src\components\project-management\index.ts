// Экспорт компонентов управления проектами для code-splitting
export { default as ProjectDirectory } from '../ProjectDirectory';
export { QualificationObjectForm } from '../QualificationObjectForm';
export { QualificationObjectsTable } from '../QualificationObjectsTable';
export { QualificationWorkSchedule } from '../QualificationWorkSchedule';

