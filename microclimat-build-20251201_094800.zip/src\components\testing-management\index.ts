// Экспорт компонентов управления испытаниями для code-splitting
export { default as TestingExecution } from '../TestingExecution';
export { TestingPeriodsCRUD } from '../TestingPeriodsCRUD';

