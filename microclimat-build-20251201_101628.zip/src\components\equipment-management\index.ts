// Экспорт компонентов управления оборудованием для code-splitting
export { default as EquipmentDirectory } from '../EquipmentDirectory';
export { EquipmentPlacement } from '../EquipmentPlacement';

