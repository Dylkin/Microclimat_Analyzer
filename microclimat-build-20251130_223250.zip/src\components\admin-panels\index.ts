// Экспорт компонентов административных панелей для code-splitting
export { default as UserDirectory } from '../UserDirectory';
export { default as ContractorDirectory } from '../ContractorDirectory';

